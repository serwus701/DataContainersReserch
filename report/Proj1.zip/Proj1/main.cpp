#include "Interface.h"

int main() {
    Interface::run();
}