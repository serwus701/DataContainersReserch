//
// Created by serwu on 21.04.2022.
//

#include "MyRedBlackTree.h"

void MyRedBlackTree::addElement() {
    //RBTElement * newElement = new RBTElement();
    if(size == 0){
    }
}
